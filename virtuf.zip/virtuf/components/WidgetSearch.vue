<template>
    <div class="widget" data-aos="fade-up" data-aos-duration="1000">
        <div class="widget-search-box">
            <form>
                <div class="form-input-item">
                    <label for="search2" class="sr-only">Search Here</label>
                    <input type="text" id="search2" placeholder="Search Here">
                    <button type="submit" class="btn-src"><i class="icofont-search-2"></i></button>
                </div>
            </form>
        </div>
    </div>
</template>

<script>
    export default {

    };
</script>
