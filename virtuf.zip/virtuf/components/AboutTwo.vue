<template>
    <section class="about-area">
        <div class="position-relative">
            <div class="container">
                <div class="row">
                    <div class="col-md-8 offset-md-2 col-lg-6 offset-lg-3 col-xl-6 offset-xl-0">
                        <div class="layer-about-style" data-aos="fade-up" data-aos-duration="1000">
                            <div class="thumb tilt-animation">
                                <img src="/images/about/02.jpg" alt="image">
                            </div>
                            <div class="shape-style1">
                                <img src="/images/shape/1.png" alt="image">
                            </div>
                            <div class="experience-time">
                                <div class="content">
                                    32<sup>+</sup>
                                    <div class="line-separetor">
                                        <img src="/images/shape/line-s4.png" alt="image">
                                        <img src="/images/shape/line-s4.png" alt="image">
                                    </div>
                                    <span>Years of Experience</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12 col-xl-6">
                        <div class="about-content-style2">
                            <div class="section-title" data-aos="fade-up" data-aos-duration="1000">
                                <div class="subtitle-content">
                                    <img src="/images/shape/line1.png" alt="image">
                                    <h5>About Us.</h5>
                                </div>
                                <h2 class="title">Grow Your Business With Us <span>Since 1987.</span></h2>
                                <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry standard dummy text ever centuries.</p>
                            </div>
                            <div class="inner-content" data-aos="fade-up" data-aos-duration="1200">
                                <p><span class="text-block">B</span>omply dummy text of the printing and typesetting industry. has standard dummy text ever since the 1500s, when an unknown printer scrambled it to make a type and specimen book. It has survived not only five leap into electronic typesetting, remaining essentially unchanged popularise with the release Letraset sheets containing.</p>
                                <p class="mb-0">Lorem Ipsum is simply dummy text of the printing and typesetting industry has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type electronic typesetting, remaining essentially.</p>
                                <div class="inline-style">
                                    <a href="#" class="btn btn-theme btn-border">
                                        Team Members 
                                        <i class="icon icofont-long-arrow-right"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>
