<template>
    <section class="contact-area">
        <div class="contact-info-light" data-aos="fade-up" data-aos-duration="1000">
            <div class="contact-info-content">
                <div class="contact-info-item">
                    <div class="icon">
                        <img class="icon-img" src="/images/icons/c1.png" alt="Icon">
                    </div>
                    <div class="content">
                        <h4>Call Us.</h4>
                        <img class="line-icon" src="/images/shape/line-s1.png" alt="Icon">
                        <a href="tel://88123456789">(88) 123 456 789</a>
                        <a href="tel://000111234567">000 111 234 567</a>
                    </div>
                </div>
                <div class="contact-info-item">
                    <div class="icon">
                        <img class="icon-img" src="/images/icons/c2.png" alt="Icon">
                    </div>
                    <div class="content">
                        <h4>Email.</h4>
                        <img class="line-icon" src="/images/shape/line-s1.png" alt="Icon">
                        <a href="mailto://support@gmail.com">support@gmail.com</a>
                        <a href="mailto://domain@gmail.com">domain@gmail.com</a>
                    </div>
                </div>
                <div class="contact-info-item">
                    <div class="icon">
                        <img class="icon-img" src="/images/icons/c3.png" alt="Icon">
                    </div>
                    <div class="content">
                        <h4>Location.</h4>
                        <img class="line-icon" src="/images/shape/line-s1.png" alt="Icon">
                        <p>Your address goes here <br>New York, USA</p>
                    </div>
                </div>
            </div>
        </div>
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="contact-colunm" data-aos="fade-up" data-aos-duration="1000">
                        <div class="contact-map-area">
                            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3151.8402891185374!2d144.95373631590425!3d-37.81720974201477!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x6ad65d4c2b349649%3A0xb6899234e561db11!2sEnvato!5e0!3m2!1sen!2ssg!4v1607294780661!5m2!1sen!2ssg"></iframe>
                        </div>
                        <div class="contact-form">
                            <form class="contact-form-wrapper">
                                <div class="row">
                                    <div class="col-lg-12">
                                        <div class="section-title">
                                            <div class="subtitle-content">
                                                <img src="/images/shape/line-s4.png" alt="shape">
                                                <h5 class="text-light">Contact Us</h5>
                                            </div>
                                            <h2 class="title text-light">Get In <span>Touch.</span></h2>
                                            <div class="separator-line">
                                                <img src="/images/shape/line-s4.png" alt="shape">
                                                <img src="/images/shape/line-s4.png" alt="shape">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <input class="form-control" type="text" name="con_name" placeholder="Name">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <input class="form-control" type="email" name="con_email" placeholder="Email">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <input class="form-control" type="text" name="con_phone" placeholder="Phone">
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group mb-0">
                                            <textarea name="con_message" placeholder="Message"></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-group mb-0">
                                            <button class="btn btn-theme" type="submit">Submit Now <i class="icofont-long-arrow-right"></i></button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
</template>

<script>
    export default {

    };
</script>

<style lang="scss" scoped>

</style>